// state.js — dito nakatago yung shared data at storage helpers. Wala pang
// rendering dito, purong data lang para madali i-trace kung saan galing lahat.

const STORAGE_KEY = 'sagip_cases';
const RESCUED_KEY = 'sagip_total_rescued'; // hiwalay na counter, kasi tinatanggal na natin sa list yung rescued case
const ROLE_KEY = 'sagip_role';
const THEME_KEY = 'sagip_theme';
const RESCUER_PASSCODE = 'MDRRMO2026'; // demo lang toh, palitan ng tunay na auth pag deploy na for real

// Sample na center: paligid ng Marikina/QC/Pasig, para makita sa isang view
// yung incident zone pati yung mga station na from "all over" — hindi lang Marikina.
const MAP_CENTER = [14.6150, 121.0450];
const MAP_DEFAULT_ZOOM = 12;

// Ito yung mga aktibong case ngayon. Pag na-"Rescued" na yung isang case,
// tinatanggal na siya dito (see cases.js advanceCase) — hindi lang pinapalitan
// yung status niya, para hindi na siya lumabas sa "needs rescue" queue.
const seedCases = [
  { id: 1, name: 'Sto. Niño resident', cat: 'PWD', hazard: 'landslide', addr: 'Sto. Niño, Marikina · Grid C4', phone: '', status: 'Need rescue', code: '#1048', time: '10:39', lat: 14.6282, lng: 121.0952 },
  { id: 2, name: 'Nangka resident', cat: 'Pregnant', hazard: 'flood', addr: 'Nangka, Marikina · Grid B2', phone: '', status: 'Need rescue', code: '#1051', time: '10:35', lat: 14.6652, lng: 121.1148 },
  { id: 3, name: 'Fortune family', cat: 'Family', hazard: 'landslide', addr: 'Fortune, Marikina · Grid A7', phone: '', status: 'Need rescue', code: '#1042', time: '10:28', lat: 14.6598, lng: 121.1201 }
];

// Mga aktibong unit — galing sila sa totoong klase ng station (fire/ambulance),
// spread out sa iba't-ibang lungsod, hindi lang Marikina. "caseId: null" ibig
// sabihin nakatambay pa sila sa station nila — hindi sila gagalaw hangga't
// walang na-a-assign na rescuer sa kanila (see dispatch.js).
let units = [
  { id: 'R1', station: 'BFP Marikina Fire Station', city: 'Marikina', lat: 14.6507, lng: 121.1029, caseId: null, speed: 0.00035, arrived: false },
  { id: 'R2', station: 'Pasig DRRMO Ambulance', city: 'Pasig', lat: 14.5764, lng: 121.0851, caseId: null, speed: 0.00030, arrived: false },
  { id: 'R3', station: 'Quezon City Fire Station - Cubao', city: 'Quezon City', lat: 14.6194, lng: 121.0526, caseId: null, speed: 0.00028, arrived: false }
];

const offlineUnits = [
  { id: 'R4', station: 'San Juan Fire Station', loc: 'San Juan', status: 'Standby' },
  { id: 'R5', station: 'Makati Ambulance Corps', loc: 'Makati', status: 'Standby' },
  { id: 'R6', station: 'Caloocan Fire Station', loc: 'Caloocan', status: 'Off duty' },
  { id: 'R7', station: 'NDRRMC Rescue HQ', loc: 'Quezon City', status: 'Off duty' }
];

let alerts = [
  { id: 1, sev: 'severe', text: 'River level rising at Nangka Bridge, Marikina; slope movement detected in Fortune.', time: '3 min ago' },
  { id: 2, sev: 'watch', text: 'Heavy rainfall advisory for Metro Manila and nearby provinces, next 6 hours.', time: '22 min ago' },
  { id: 3, sev: 'info', text: 'Barangay Tumana evacuation center now open.', time: '40 min ago' }
];

function loadCases() {
  try {
    const v = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return Array.isArray(v) && v.length ? v : seedCases.slice();
  } catch (e) { return seedCases.slice(); }
}
function saveCases(list) { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(list)); } catch (e) {} }

function loadTotalRescued() { try { return parseInt(localStorage.getItem(RESCUED_KEY) || '0', 10) || 0; } catch (e) { return 0; } }
function bumpTotalRescued() { const n = loadTotalRescued() + 1; try { localStorage.setItem(RESCUED_KEY, String(n)); } catch (e) {} return n; }

function getRole() { return sessionStorage.getItem(ROLE_KEY) || 'civilian'; }
function persistRole(role) { try { sessionStorage.setItem(ROLE_KEY, role); } catch (e) {} }

function getTheme() { try { return localStorage.getItem(THEME_KEY) || 'light'; } catch (e) { return 'light'; } }
function persistTheme(t) { try { localStorage.setItem(THEME_KEY, t); } catch (e) {} }

function isP1(cat) { return cat === 'Pregnant' || cat === 'Elderly' || cat === 'PWD'; }
function haversine(aLat, aLng, bLat, bLng) {
  return Math.hypot(aLat - bLat, aLng - bLng); // sapat na toh for short in-city distances
}

// Isang lugar lang toh para sa search filter — ginagamit ng map pins AT ng
// queue list, kasi dati magkahiwalay sila kaya parang "sira" yung search dati.
function currentSearchQuery() {
  const map = (document.getElementById('mapSearch') || {}).value || '';
  const top = (document.getElementById('topSearch') || {}).value || '';
  return (map + ' ' + top).trim().toLowerCase();
}
function matchesSearch(c, q) {
  if (!q) return true;
  return (c.name || '').toLowerCase().includes(q) || (c.addr || '').toLowerCase().includes(q) || (c.code || '').toLowerCase().includes(q);
}
