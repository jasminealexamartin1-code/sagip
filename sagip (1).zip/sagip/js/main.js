// main.js — dito nakaconnect lahat: nav, hazard tabs, dark/light toggle, at
// yung render() na tumatawag sa lahat ng ibang render function para laging
// magkatugma yung stats, queue, map, responders, at alerts.

let activeNav = 'map';
let activeHazard = 'all';

function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 1700);
}

function setNav(view) {
  if (currentRole === 'civilian' && (view === 'queue' || view === 'responders')) view = 'map';
  activeNav = view;
  ['navMap', 'navQueue', 'navResp', 'navAlerts'].forEach(id => document.getElementById(id).classList.remove('active'));
  const navId = { map: 'navMap', queue: 'navQueue', responders: 'navResp', alerts: 'navAlerts' }[view];
  if (navId) document.getElementById(navId).classList.add('active');
  ['viewMap', 'viewQueue', 'viewResponders', 'viewAlerts'].forEach(id => document.getElementById(id).classList.add('hidden'));
  const target = { map: 'viewMap', queue: 'viewQueue', responders: 'viewResponders', alerts: 'viewAlerts' }[view];
  document.getElementById(target).classList.remove('hidden');
  setTimeout(() => map && map.invalidateSize(), 150);
  render();
}

function setHazard(hz) {
  activeHazard = hz;
  document.querySelectorAll('.hazard').forEach(h => h.classList.toggle('active', h.dataset.hz === hz));
  setHazardFilterOnMap(hz);
  render();
}

// Toggle ng light/dark — naka-save sa localStorage kaya di na uulit magtanong
// sa susunod na bukas ng page. Kasama na rin dito yung pagpalit ng map tiles.
function toggleTheme() {
  const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  persistTheme(next);
}
function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  const knob = document.getElementById('themeKnob');
  if (knob) knob.textContent = theme === 'dark' ? '🌙' : '☀';
  setMapTheme(theme);
}

function render(list) {
  list = list || loadCases();
  renderStats(list);
  renderCaseList(list);
  renderQueueFull(list);
  renderMapMarkers(list);
  renderMapUnits(list);
  renderResponders();
  renderAlerts();
  document.getElementById('mapTime').textContent = new Date().toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function tick() {
  const list = loadCases();
  tickMovement(list);
  render(list);
}

document.addEventListener('DOMContentLoaded', () => {
  applyTheme(getTheme());
  initMap();
  currentRole = getRole();
  applyRoleUI();
  setHazard('all');
  render();
  setInterval(tick, 1400);
  setInterval(() => { document.getElementById('clock').textContent = new Date().toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit' }) + ' PHT'; }, 30000);
});
