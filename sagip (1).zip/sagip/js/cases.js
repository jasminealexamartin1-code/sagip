// cases.js — dito ginagalaw yung case data (add/assign/rescue) pati yung
// pag-render ng queue at case cards. Yung rescuer-only screens, CSS na lang
// bahala magtago sa civilian, pero dito naman yung logic mismo.

function openReportModal(isCivilian) {
  document.getElementById('reportTitle').textContent = isCivilian
    ? 'Report someone who needs rescue'
    : 'Register a civilian needing rescue';
  document.getElementById('modalBg').classList.remove('hidden');
}
function closeModal() { document.getElementById('modalBg').classList.add('hidden'); }

function useLocation() {
  if (!navigator.geolocation) { toast('Hindi supported ang geolocation sa device na to'); return; }
  toast('Kinukuha yung location mo…');
  navigator.geolocation.getCurrentPosition(pos => {
    const { latitude, longitude } = pos.coords;
    const f = document.getElementById('fAddr');
    f.value = `GPS ${latitude.toFixed(5)}, ${longitude.toFixed(5)}`;
    f.dataset.lat = latitude; f.dataset.lng = longitude;
    toast('Nakuha na yung location');
  }, err => { toast('Hindi nakuha yung location: ' + err.message); }, { enableHighAccuracy: true, timeout: 8000 });
}

function addCase() {
  const name = document.getElementById('fName').value.trim();
  const addrEl = document.getElementById('fAddr');
  const addr = addrEl.value.trim();
  if (!name || !addr) { toast('Please enter a name and location'); return; }
  const cat = document.getElementById('fCat').value;
  const hazard = document.getElementById('fHazard').value;
  const phone = document.getElementById('fPhone').value.trim();
  const list = loadCases();
  const n = list.length + 1;
  const lat = addrEl.dataset.lat ? parseFloat(addrEl.dataset.lat) : MAP_CENTER[0] + (Math.random() - 0.5) * 0.05;
  const lng = addrEl.dataset.lng ? parseFloat(addrEl.dataset.lng) : MAP_CENTER[1] + (Math.random() - 0.5) * 0.05;
  list.unshift({ id: Date.now(), name, cat, hazard, addr, phone, status: 'Need rescue', code: '#' + (1040 + n), time: 'now', lat, lng });
  saveCases(list);
  document.getElementById('fName').value = ''; addrEl.value = ''; document.getElementById('fPhone').value = '';
  delete addrEl.dataset.lat; delete addrEl.dataset.lng;
  closeModal();
  toast('Case submitted — a rescuer will assign a team');
  render();
}

// Dito lang talaga nagliligawan yung unit sa case — kailangan i-click muna toh
// bago gumalaw yung unit. Pag na-rescue na, TINATANGGAL na natin sa listahan
// (hindi lang pinapalitan yung status), kaya hindi na siya lalabas sa "needs
// rescue" queue kahit saan pa — yung bilang na lang ng na-rescue ang naiiwan.
function advanceCase(id) {
  let list = loadCases();
  const c = list.find(x => x.id === id);
  if (!c) return;
  if (c.status === 'Need rescue') {
    c.status = 'Assigned';
    saveCases(list);
    const unit = assignNearestIdleUnit(c);
    toast(unit ? `Unit ${unit.id} (${unit.station}) assigned and moving` : 'Busy lahat ng units — pag-uunahan na lang pag may nag-free');
  } else if (c.status === 'Assigned') {
    const u = units.find(u => u.caseId === id);
    if (u) { u.caseId = null; u.arrived = false; }
    list = list.filter(x => x.id !== id); // tanggal na sa needs-rescue queue
    saveCases(list);
    bumpTotalRescued();
    toast('Case marked rescued — tinanggal na sa queue');
  }
  render();
}

function renderStats(list) {
  const need = list.filter(c => c.status === 'Need rescue').length;
  const assigned = list.filter(c => c.status === 'Assigned').length;
  const rescued = loadTotalRescued(); // hiwalay na counter, hindi galing sa active list
  const enRoute = units.filter(u => u.caseId && !u.arrived).length;
  document.getElementById('stNeed').textContent = need;
  document.getElementById('stAssign').textContent = assigned;
  document.getElementById('stDone').textContent = rescued;
  document.getElementById('stEnRoute').textContent = enRoute + ' currently en route';
  document.getElementById('navNeed').textContent = need;
  document.getElementById('queueCount').textContent = need + assigned;
  document.getElementById('stP1').textContent = list.filter(c => isP1(c.cat)).length + ' priority-one cases';
}

function caseCardHTML(c) {
  const u = units.find(x => x.caseId === c.id);
  let eta;
  if (u) eta = u.arrived ? `Unit ${u.id} on scene` : `${Math.max(1, Math.ceil(haversine(u.lat, u.lng, c.lat, c.lng) / u.speed))} min · Unit ${u.id} en route`;
  else if (c.status === 'Assigned') eta = 'Waiting for a free unit';
  else eta = 'Awaiting assignment';
  const btnLabel = c.status === 'Need rescue' ? 'Assign team' : 'Mark rescued';
  return `<div class="case-card">
    <div class="case-top"><span class="priority ${isP1(c.cat) ? 'urgent' : ''}">${isP1(c.cat) ? 'P1' : 'P2'}</span><strong>${c.code}</strong><time>${c.time}</time></div>
    <p><strong>${c.addr.split(' · ')[0]}</strong> · ${c.addr.split(' · ')[1] || ''}</p>
    <span class="case-note">${c.cat}${c.name ? ' · ' + c.name : ''}</span>
    <span class="case-note case-eta">${eta}</span>
    <div class="cc-actions">
      <div class="cc-btn primary" onclick="advanceCase(${c.id})">${btnLabel}</div>
    </div>
  </div>`;
}

// Nilagyan na ng search filter dito — dati sa map pins lang toh gumagana,
// kaya parang "sira" yung search kasi hindi nagbabago yung listahan sa tabi.
function visibleCases(list) {
  const q = currentSearchQuery();
  return list.filter(c => matchesSearch(c, q));
}

function renderCaseList(list) {
  const sorted = [...visibleCases(list)].sort((a, b) => isP1(b.cat) - isP1(a.cat));
  document.getElementById('caseList').innerHTML = sorted.map(caseCardHTML).join('') || '<p class="case-note">Walang active case na tumutugma.</p>';
}

function renderQueueFull(list) {
  const el = document.getElementById('queueFullList');
  if (!el) return;
  const sorted = [...visibleCases(list)].sort((a, b) => isP1(b.cat) - isP1(a.cat));
  el.innerHTML = sorted.map(caseCardHTML).join('') || '<p class="case-note">Walang active case na tumutugma.</p>';
}
