// map.js — Leaflet map (OpenStreetMap tiles), ginawang parang ride-hailing app
// yung itsura: pins, rider pucks, dashed route lines. May dark tile variant din
// para tumugma sa dark mode.

let map, caseLayer, unitLayer, routeLayer, floodZone, landslideZone, evacLayer;
let lightTiles, darkTiles;

function initMap() {
  map = L.map('leafletMap', { zoomControl: false }).setView(MAP_CENTER, MAP_DEFAULT_ZOOM);

  lightTiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, attribution: '&copy; OpenStreetMap contributors'
  });
  darkTiles = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    maxZoom: 19, attribution: '&copy; OpenStreetMap contributors &copy; CARTO'
  });
  (getTheme() === 'dark' ? darkTiles : lightTiles).addTo(map);

  L.control.zoom({ position: 'topright' }).addTo(map);

  // "Put back" na recenter button — parang yung dati bago naging Leaflet.
  const Recenter = L.Control.extend({
    options: { position: 'topright' },
    onAdd: function () {
      const btn = L.DomUtil.create('div', 'leaflet-bar map-recenter-btn');
      btn.innerHTML = '◎';
      btn.title = 'Recenter map';
      L.DomEvent.on(btn, 'click', L.DomEvent.stopPropagation).on(btn, 'click', () => map.setView(MAP_CENTER, MAP_DEFAULT_ZOOM));
      return btn;
    }
  });
  new Recenter().addTo(map);

  caseLayer = L.layerGroup().addTo(map);
  unitLayer = L.layerGroup().addTo(map);
  routeLayer = L.layerGroup().addTo(map);
  evacLayer = L.layerGroup().addTo(map);

  floodZone = L.circle([14.6652, 121.1148], { radius: 550, color: '#236b8b', weight: 1.5, fillColor: '#3b9aba', fillOpacity: 0.14 }).addTo(map);
  landslideZone = L.circle([14.6598, 121.1201], { radius: 480, color: '#91653c', weight: 1.5, fillColor: '#a77944', fillOpacity: 0.14 }).addTo(map);

  L.marker([14.6390, 121.1130], { icon: evacIcon() }).addTo(evacLayer).bindTooltip('Tumana evacuation center', { direction: 'top' });

  // Mga station marker ng units — para makita talaga na iba't-ibang lungsod
  // ang pinagmumulan ng mga rescuer, hindi lang Marikina.
  units.forEach(u => {
    L.circleMarker([u.lat, u.lng], { radius: 5, color: '#3d7891', weight: 2, fillColor: '#deebef', fillOpacity: 1 })
      .addTo(evacLayer)
      .bindTooltip(`${u.station} · ${u.city}`, { direction: 'top' });
  });
}

function setMapTheme(theme) {
  if (!map) return;
  const wantDark = theme === 'dark';
  if (wantDark) { if (map.hasLayer(lightTiles)) map.removeLayer(lightTiles); if (!map.hasLayer(darkTiles)) darkTiles.addTo(map); }
  else { if (map.hasLayer(darkTiles)) map.removeLayer(darkTiles); if (!map.hasLayer(lightTiles)) lightTiles.addTo(map); }
}

function pinIcon(color, label) {
  const svg = `<svg viewBox="0 0 24 30" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 0C5.4 0 0 5.3 0 11.8 0 20.6 12 30 12 30s12-9.4 12-18.2C24 5.3 18.6 0 12 0z" fill="${color}"/>
    <circle cx="12" cy="11.5" r="5.4" fill="#fff"/>
  </svg>`;
  return L.divIcon({
    className: '',
    html: `<div class="case-pin">${svg}<span class="case-pin-label" style="color:${color}">${label}</span></div>`,
    iconSize: [30, 38], iconAnchor: [15, 36]
  });
}

function unitIcon(id) {
  return L.divIcon({
    className: '',
    html: `<div class="unit-puck"><div class="unit-pulse"></div><span>${id}</span><div class="unit-eta-pill" data-eta-for="${id}"></div></div>`,
    iconSize: [30, 30], iconAnchor: [15, 15]
  });
}

function evacIcon() {
  return L.divIcon({
    className: '',
    html: `<div style="width:1.6rem;height:1.6rem;border-radius:.35rem;background:#2f7d54;border:.13rem solid #fff;box-shadow:0 .2rem .5rem rgba(20,40,30,.3);display:grid;place-items:center;color:#fff;font-size:.65rem;font-weight:800">E</div>`,
    iconSize: [26, 26], iconAnchor: [13, 13]
  });
}

// Hindi makikita ng civilian yung exact na lokasyon ng biktima/unit sa shared
// map — hazard zone lang at evac center. Buong operational picture, sa rescuer
// lang bukas.
function refreshMapForRole() {
  [caseLayer, unitLayer, routeLayer].forEach(layer => {
    if (currentRole === 'rescuer') { if (!map.hasLayer(layer)) layer.addTo(map); }
    else { if (map.hasLayer(layer)) map.removeLayer(layer); }
  });
  setTimeout(() => map && map.invalidateSize(), 200);
}

function setHazardFilterOnMap(hz) {
  const showFlood = hz === 'all' || hz === 'flood';
  const showSlide = hz === 'all' || hz === 'landslide';
  if (showFlood) { if (!map.hasLayer(floodZone)) floodZone.addTo(map); } else if (map.hasLayer(floodZone)) map.removeLayer(floodZone);
  if (showSlide) { if (!map.hasLayer(landslideZone)) landslideZone.addTo(map); } else if (map.hasLayer(landslideZone)) map.removeLayer(landslideZone);
  document.getElementById('hazardNote').classList.toggle('hidden', !(hz === 'fire' || hz === 'quake'));
}

function renderMapMarkers(list) {
  caseLayer.clearLayers();
  const q = currentSearchQuery();
  list.filter(c => activeHazard === 'all' || c.hazard === activeHazard)
    .filter(c => matchesSearch(c, q))
    .forEach(c => {
      const color = isP1(c.cat) ? '#9f5261' : '#a77735';
      L.marker([c.lat, c.lng], { icon: pinIcon(color, c.cat.slice(0, 2).toUpperCase()) })
        .addTo(caseLayer)
        .bindTooltip(`${c.code} · ${c.addr}`, { direction: 'top' });
    });
}

function renderMapUnits(list) {
  unitLayer.clearLayers();
  routeLayer.clearLayers();
  units.forEach(u => {
    const marker = L.marker([u.lat, u.lng], { icon: unitIcon(u.id) }).addTo(unitLayer);
    if (u.caseId) {
      const c = list.find(x => x.id === u.caseId);
      if (c) {
        if (!u.arrived) {
          L.polyline([[u.lat, u.lng], [c.lat, c.lng]], { color: '#3d7891', weight: 3, opacity: 0.85, className: 'route-line' }).addTo(routeLayer);
        }
        setTimeout(() => {
          const pill = marker.getElement() && marker.getElement().querySelector(`[data-eta-for="${u.id}"]`);
          if (pill) pill.textContent = u.arrived ? 'On scene' : Math.max(1, Math.ceil(haversine(u.lat, u.lng, c.lat, c.lng) / u.speed)) + ' min';
        }, 0);
      }
    }
  });
}
