// dispatch.js — dito nangyayari yung paggalaw ng units. Hindi sila gagalaw
// hangga't walang rescuer na nag-"Assign team" — pagkatapos lang non, saka
// sila mag-uumpisang lumapit, tick by tick, papunta sa case.

const ARRIVE_THRESHOLD = 0.0006; // parang 60-70m lang toh sa latitude natin dito

function assignNearestIdleUnit(caseObj) {
  const idle = units.filter(u => !u.caseId);
  if (!idle.length) return null;
  let best = idle[0], bestDist = Infinity;
  idle.forEach(u => {
    const d = haversine(u.lat, u.lng, caseObj.lat, caseObj.lng);
    if (d < bestDist) { bestDist = d; best = u; }
  });
  best.caseId = caseObj.id;
  best.arrived = false;
  return best;
}

// Minsan "Assigned" na yung case pero walang libreng unit (busy lahat).
// Chinicheck to every tick para pag may nag-free na unit, agad niyang kunin
// yung pinakamatagal na naghihintay na case — hindi bagong case, dahil manual
// pa rin yung pag-assign, walang auto-dispatch ng FRESH na case dito.
function checkPendingAssignments(list) {
  const waiting = list.filter(c => c.status === 'Assigned' && !units.some(u => u.caseId === c.id));
  waiting.forEach(c => assignNearestIdleUnit(c));
}

function tickMovement(list) {
  checkPendingAssignments(list);
  units.forEach(u => {
    if (!u.caseId) return;
    const c = list.find(x => x.id === u.caseId);
    if (!c) { u.caseId = null; u.arrived = false; return; }
    const d = haversine(u.lat, u.lng, c.lat, c.lng);
    if (d < ARRIVE_THRESHOLD) { u.arrived = true; return; }
    u.arrived = false;
    u.lat += (c.lat - u.lat) / d * u.speed;
    u.lng += (c.lng - u.lng) / d * u.speed;
  });
}
