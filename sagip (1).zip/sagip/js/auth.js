// auth.js — dito yung login gate ng rescuer/admin console. Yung civilian, wala
// silang makikita dito na exact location o queue — map at alerts lang for them.

let currentRole = 'civilian';

function requestRole(role) {
  if (role === 'civilian') {
    currentRole = 'civilian';
    persistRole('civilian');
    applyRoleUI();
    setNav('map');
    return;
  }
  // Pag rescuer yung hiningi, kailangan pumasa muna sa passcode gate.
  if (currentRole === 'rescuer') return; // naka-sign in na
  document.getElementById('loginBg').classList.remove('hidden');
  document.getElementById('loginPass').value = '';
  document.getElementById('loginPass').focus();
}

function closeLogin() { document.getElementById('loginBg').classList.add('hidden'); }

function trySignIn() {
  const val = document.getElementById('loginPass').value.trim();
  if (val === RESCUER_PASSCODE) {
    currentRole = 'rescuer';
    persistRole('rescuer');
    closeLogin();
    applyRoleUI();
    toast('Signed in as rescuer');
  } else {
    toast('Mali yung passcode, subukan ulit');
  }
}

function applyRoleUI() {
  document.body.classList.toggle('role-civilian', currentRole === 'civilian');
  document.body.classList.toggle('role-rescuer', currentRole === 'rescuer');
  document.getElementById('modeCiv').classList.toggle('active', currentRole === 'civilian');
  document.getElementById('modeRes').classList.toggle('active', currentRole === 'rescuer');
  document.getElementById('modeLabel').textContent = currentRole === 'civilian' ? 'CIVILIAN VIEW · STAY SAFE' : 'OPERATIONAL PICTURE · SHIFT B';
  document.getElementById('heroTitle').textContent = currentRole === 'civilian' ? 'Help is on the way. Report anyone at risk.' : 'People first. Every case accounted for.';
  document.querySelector('#registerBtn span').textContent = currentRole === 'civilian' ? 'Report someone at risk' : 'Register civilian';
  document.getElementById('topSubtitle').textContent = currentRole === 'civilian'
    ? 'Metro Manila · Public safety updates'
    : 'Incident MRC-0927 · Multi-city hazard response';
  // Kapag civilian tumingin sa queue o responders na URL/state, ibalik na lang sa map.
  if (currentRole === 'civilian' && (activeNav === 'queue' || activeNav === 'responders')) setNav('map');
  refreshMapForRole();
  render();
}
