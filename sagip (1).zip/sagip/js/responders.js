// responders.js — roster view (rescuer-only). Makikita dito na galing sa
// iba't-ibang lungsod ang mga unit — hindi lang Marikina.

function renderResponders() {
  const el = document.getElementById('responderList');
  if (!el) return;
  const online = units.map(u => `<div class="resp-row"><span class="resp-dot online"></span><div><p>${u.id} · ${u.station}</p><p class="case-note">${u.city} · ${u.caseId ? (u.arrived ? 'On scene' : 'En route') : 'Idle · awaiting assignment'}</p></div></div>`);
  const offline = offlineUnits.map(u => `<div class="resp-row"><span class="resp-dot offline"></span><div><p>${u.id} · ${u.station}</p><p class="case-note">${u.loc} · ${u.status}</p></div></div>`);
  el.innerHTML = online.join('') + offline.join('');
}
