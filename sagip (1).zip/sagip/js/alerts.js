// alerts.js — public safety alerts. Kitang-kita to ng civilian AT ng rescuer,
// dahil pareho silang dapat may alam sa mga babala.

function renderAlerts() {
  document.getElementById('navAlertCount').textContent = alerts.length;
  const el = document.getElementById('alertList');
  if (!el) return;
  el.innerHTML = alerts.map(a => `<div class="alert-row">
      <div><span class="alert-sev ${a.sev}">${a.sev.toUpperCase()}</span><p style="margin-top:.4rem">${a.text}</p><p class="case-note">${a.time}</p></div>
      <span class="dismiss-btn rescuer-only" onclick="dismissAlert(${a.id})">Dismiss</span>
    </div>`).join('');
}

function dismissAlert(id) {
  alerts = alerts.filter(a => a.id !== id);
  renderAlerts();
}
