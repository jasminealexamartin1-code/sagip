// sw.js — simple offline cache para gumana parang app kahit walang signal.
// Cache-first: kung nasa cache na, dun kunin; kung wala, saka lang mag-fetch sa network.
const CACHE = 'sagip-cache-v1';
const FILES = [
  './', './index.html', './css/styles.css',
  './js/state.js', './js/auth.js', './js/map.js', './js/dispatch.js',
  './js/cases.js', './js/responders.js', './js/alerts.js', './js/main.js',
  './manifest.json', './icons/icon-192.png', './icons/icon-512.png'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  // Third-party tiles/fonts (Leaflet, OSM, Google Fonts) — hayaan lang dumaan sa network,
  // wag i-cache kasi mabilis mag-change at malaki-laki.
  if (!e.request.url.startsWith(self.location.origin)) return;
  e.respondWith(caches.match(e.request).then(hit => hit || fetch(e.request)));
});
